#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct Mahasiswa{
	char NIM[15];
	char nama[25];
	int umur;
	struct Mahasiswa *next, *prev;
}*head = NULL, *tail  = NULL, *curr = NULL;

void push_head(char NIM[], char nama[], int umur){
	curr = (struct Mahasiswa*)malloc(sizeof(struct Mahasiswa));
	strcpy(curr->NIM, NIM);
	strcpy(curr->nama, nama);
	curr->umur = umur;
	
	curr->next = NULL;
	curr->prev = NULL;
	
	if(head == NULL){
		head = tail = curr;
	}
	else{
		curr->next = head;
		head->prev = curr;
		head = curr;
	}
	head->prev = NULL;
}

void push_tail(char NIM[], char nama[], int umur){
	curr = (struct Mahasiswa*)malloc(sizeof(struct Mahasiswa));
	strcpy(curr->NIM, NIM);
	strcpy(curr->nama, nama);
	curr->umur = umur;
	
	curr->next = NULL;
	curr->prev = NULL;
	
	if(head == NULL){
		head = tail = curr;
	}
	else{
		tail->next = curr;
		curr->prev = tail;
		tail = curr;
	}
	tail->next = NULL;
}

void push_mid(char NIM[], char nama[], int umur){
	curr = (struct Mahasiswa*)malloc(sizeof(struct Mahasiswa));
	strcpy(curr->NIM, NIM);
	strcpy(curr->nama, nama);
	curr->umur = umur;
	
	curr->next = NULL;
	curr->prev = NULL;
	
	//Jika head lebih besar daripada curr
	if(head == NULL){
		head = tail = curr;
	}
	else if(strcmp(head->NIM, curr->NIM) > 0){
		push_head(NIM, nama, umur);
	}
	//Jika tail lebih kecil daripada curr
	else if(strcmp(tail->NIM, curr->NIM) < 0){
		push_tail(NIM, nama, umur);
	}
	else{
		struct Mahasiswa *pos = head;
		while(strcmp(pos->next->NIM, curr->NIM) < 0){
			pos = pos->next;
		}
		curr->next = pos->next;
		pos->next->prev = curr;
		pos->next =  curr;
		curr->prev = pos;
	}
}

void pop_head(){
	
	if (head == NULL){
		return;	
	}
	if(head == tail){
		free(head);
		head = tail = NULL;
	}
	else{
		curr = head;
		head = head->next;
		free(curr);
		head->prev = NULL;
	}
}

void pop_tail(){
	
	if (head == NULL){
		return;	
	}
	if(head == tail){
		free(head);
		head = tail = NULL;
	}
	else{
		curr = tail;
		tail = tail->prev;
		free(curr);
		tail->next = NULL;
	}
}

void view(){
	curr = head;
	if(curr == NULL){
		return;
	}
	while(curr != NULL){
		printf("%s - %s - %d\n", curr->NIM,  curr->nama, curr->umur);
		curr = curr->next;
	}
	printf("\n");
}

void pop_mid(char NIM[]){
	if(head == NULL){
		return;
	}
	else if(strcmp(head->NIM, NIM) == 0){
		pop_head();
	}
	else if(strcmp(tail->NIM, NIM) == 0){
		pop_tail();
	}
	else{
		curr = head;
		while(curr->next != NULL && strcmp(curr->next->NIM, NIM) !=0){
			curr = curr->next;
		}
		if(curr->next == NULL){
			return;
		}
		struct Mahasiswa *del = curr->next;
		curr->next = del->next;
		del->next->prev = curr;
		free(del);
	}
}

void search(char NIM[]){
	curr = head;
	while(curr->next != NULL && strcmp(curr->next->NIM, NIM) !=0){
		curr = curr->next;
	}
	if(curr->next == NULL){
		printf("Not Found !\n");
	}
	else{
		printf("Founded [%s] \n",  curr->next->NIM);
		printf("Nama : %s\n", curr->next->nama);
		printf("Age : %d\n", curr->next->umur);
	}
}

int main(){
	
	printf("Push Head\n");
	push_head("2301881070", "Niclauss", 20);
	push_head("2401881070", "Handy", 22);
	view();
	
	printf("==========================\n");
	printf("\n");
	
	printf("Push Tail\n");
	push_tail("2601881070", "Richie", 23);
	view();
	
	printf("==========================\n");
	printf("\n");
	
	printf("Push Mid\n");
	push_mid("2501881070", "Endrico", 20);
	push_mid("2701881070", "Salim", 22);
	push_mid("1901881070", "Ferdie", 23);
	view();
	
	printf("==========================\n");
	printf("\n");
	
	printf("Pop Head\n");
	pop_head();
	view();
	
	printf("==========================\n");
	printf("\n");
	
	printf("Pop Tail\n");
	pop_tail();
	view();
	
	printf("==========================\n");
	printf("\n");
	
	printf("Pop Mid\n");
	pop_mid("2501881070");
	view();
	
	printf("==========================\n");
	printf("\n");
	
	printf("Search: \n");
	search("2301881070");
	
	return 0;	
}
