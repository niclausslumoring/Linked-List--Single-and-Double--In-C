#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct Node{
	char name[50];
	int age;
	struct Node* next;
};

struct Node* head = NULL;
struct Node* tail = NULL;

void view_all_node(){
	struct Node* curr = head;
	while(curr != NULL){
		printf("[%s / %d] ->  ",  curr->name,  curr->age);
		
		curr = curr->next;
	}
	printf("NULL \n");
}

struct Node* create_new_node(char name[], int age){
	//sewa tempat
	struct Node* createdNode = (struct Node*) malloc(sizeof(struct Node));
	strcpy(createdNode->name, name);
	createdNode->age =  age;
	createdNode->next = NULL;
	
	return createdNode;
}

void push_head(char name[], int age){
	struct Node* toInsert =  create_new_node(name, age);
	
	if(head == NULL){
		head = toInsert;
		tail = toInsert;
	}
	else{
		toInsert->next = head;
		head = toInsert;
	}
}

void push_tail(char name[], int age){
	struct Node* toInsert = create_new_node(name,age);
	
	if (tail == NULL){
		head = toInsert;
		tail = toInsert;
	}
	else{
		tail->next = toInsert;
		tail = toInsert;
	}
}

void push_mid(char name[], int age){
	struct Node* toInsert = create_new_node(name,age);
	
	if (tail == NULL){
		head = toInsert;
		tail = toInsert;
	}
	else{
		struct Node* curr = head;
		
		while(curr->next != NULL  && curr->next->age <= age){
			curr = curr->next;
		}
		toInsert->next = curr->next;
		curr->next = toInsert;
		
		if(curr == tail){
			tail = toInsert;
		}
	}
}

struct Node* search_node(char name[]){
	struct Node* curr = head;
	
	while (curr != NULL && strcmp(curr->name, name) != 0){
		curr = curr->next;
	}
	return curr;
}

void pop_mid(char name[]){
	if (head != NULL){
		struct Node* curr = head;
		
		while(curr->next != NULL && strcmp(curr->next->name,name)!=0){
			curr = curr->next;
		}
		
		if(curr->next != NULL){
			struct Node* toDelete = curr->next;
			curr->next = toDelete->next;
		
			free(toDelete);
		}	
	}
}

void pop_head(){
	if(head != NULL){
		struct Node* temp = head;
		
		if(head == tail){
			head = NULL;
			tail = NULL;	
		}
		else{
			head = head->next;
		}
		free(temp);
	}
}

void pop_tail(){
	if(head != NULL){
		struct Node* curr = head;
		
		if(head == tail){
			head = NULL;
			tail = NULL;
			
			free(curr);	
		}
		else{
			while(curr->next != tail){
				curr = curr->next;
			}
			free(curr->next);
			curr->next = NULL;
			
			tail = curr;	
		}
	}
}

int main (){
	
	push_head("John", 18);
	view_all_node();
	getchar();
	
	push_head("Jane", 31);
	view_all_node();
	getchar();
	
	push_tail("Alice", 27);
	view_all_node();
	getchar();
	
	push_mid("Bob", 25);
	view_all_node();
	getchar();
	
	struct Node* bobNode = search_node("Bob");
	printf("Name: %s /  Age: %d\n", bobNode->name, bobNode->age);
	getchar();
	
	pop_mid("Bob");
	view_all_node();
	getchar();
	
	pop_head();
	view_all_node();
	getchar();
	
	pop_tail();
	view_all_node();
	getchar();
	
	pop_tail();
	view_all_node();
	getchar();
	
	return 0;	
}
